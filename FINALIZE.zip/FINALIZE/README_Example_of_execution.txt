
Example of Excectuion:

---------------------------------------------------------------------------------

Single run example:
1. compile gridGenerator and create a Grid

	$ mpicc -o gridGenerator gridGenerator.c
	$ mpirun gridGenerator
		Enter filename i.e. "gird1"
		Enter the Grid-Size i.e. 30
		Genereate a rectangle using option 2 i.e following Entries:
			4
			4
			24
			10
		Use option 8 to save grid to file

2. compile pixCheckTangle and run it with grid-file:
	$ mpicc -o pixCheckTangle pixCheckTangle.c 
	$ mpirun pixCheckTangle grid1.txt 


---------------------------------------------------------------------------------

Full Cluster Measurement example:
1. generate myhost-files:
	
	Change the host-name in hostfileGenerator.c
	$ clang -o hostfileGenerator hostfileGenerator.c 
	$ chmod +x ./bsCreateHostfiles.sh
	$ ./bsCreateHostfiles.sh 50

2. compile gridGenerator and create a Grid

	$ mpicc -o gridGenerator gridGenerator.c
	$ mpirun gridGenerator
		Enter filename i.e. "gird1"
		Enter the Grid-Size i.e. 30
		Genereate a rectangle using option 2 i.e following Entries:
			4
			4
			24
			10
		Use option 8 to save grid to file
	
3. compile pixCheckTangle and run full measurement:
	$ mpicc -o pixCheckTangle pixCheckTangle.c 
	Change the grid-File-Name in bsRunGrids.sh
	$ chmod +x ./bsRunGrids.sh 
	$ ./bsRunGrids.sh 
