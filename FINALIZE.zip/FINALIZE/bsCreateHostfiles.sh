for run in {1..50}
	do
	./hostfileGenerator $run
	done
